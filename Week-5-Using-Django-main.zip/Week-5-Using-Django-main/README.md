# Lab-Assignment-5-Django-app
Django app hello world
